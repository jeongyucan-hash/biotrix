# BIOTRIX Design Master 2.0

Owner: HQ 홈페이지 디자인실 / website_design

## Files
- PDF: 18-page visual design master, searchable text and vector graphics.
- AI: **PDF-based Illustrator compatibility copy, not a native Adobe Illustrator save.** The file contains one large canvas with 18 boards. It does not contain Illustrator proprietary edit data, native layers or native multi-artboard metadata. Adobe Illustrator application testing was not available. Open/import the PDF-based file in Illustrator, then Save As native AI if required. Renaming the extension alone does not make it a native AI file.
- SVG: true editable vector master, grouped by board. Individual pages in boards/. Text remains live; install Noto Sans KR to edit it. The full master embeds its image. Individual boards link to ../brand-triptych.jpg inside this package; keep the folder structure intact.
- Photos: brand-triptych.png is the original AI-generated mood image. JPG is a compressed delivery version, composition unchanged. Not actual products, facilities or suppliers.
- tokens.json: implementation values; asset-manifest.json: provenance and page index.
- biotrix-symbol-flat.svg: flat vector symbol preserving the existing B construction.

## Fonts
Noto Sans KR Regular and Bold, SIL Open Font License.
Official font source: https://github.com/google/fonts/tree/main/ofl/notosanskr
See OFL.txt. The PDFs embed font subsets. SVG editing needs the full installed font.

## Scope and release
The master defines public brand pages, mobile, commerce visual conventions and HQ design-office UI. Existing commerce behaviour is preserved. This master is not evidence of a brand website redeployment. HQ release and brand-site implementation are separately recorded in HQ.

HQ stores decisions, revision requests and release evidence. ChatGPT Work executes tasks; no unattended AI runtime is claimed.

## Final AI native step
Native AI export requires Adobe Illustrator. The supplied .ai is explicitly a PDF-compatible exchange copy; the SVG is the authoritative editable source for this delivery.
