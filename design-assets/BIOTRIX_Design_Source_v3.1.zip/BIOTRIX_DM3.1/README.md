# BIOTRIX DM-3.1 / Editorial Everyday

14 design boards owned by HQ Website Design Office. This replaces the repetitive DM-2.0 triptych direction.

Four separate generated scenes: food table, lived-in morning, beauty materials, orchard landscape. Each image is used once on the homepage. No generated image depicts an actual BIOTRIX product, person, facility or supplier.

PDF is the review master. SVG is the editable source; install Noto Sans KR from https://github.com/google/fonts/tree/main/ofl/notosanskr (SIL OFL). Main SVG embeds photos; boards/ SVGs refer to ../editorial-*.jpg. Keep the folder structure.

The .ai file is a PDF-based Illustrator exchange copy, NOT a native Adobe Illustrator save. It contains one vector canvas, no proprietary Illustrator layers/artboards. Adobe Illustrator app testing was unavailable. Use SVG or import the PDF then Save As native AI in Illustrator.

The source ZIP includes editable SVG, individual boards, images, implementation CSS/JS and provenance. PDF and AI are separate downloads to keep the package compact. Production status is recorded in HQ, not inferred from this file.
